import pandas as pd
from typing import *
import os
import matplotlib.pyplot as plt
import numpy as np

class TrajectoryVisualizer:

    
    def show(self, df: pd.DataFrame, idCol, xCol, yCol, trackIds=None):
        
        plt.rc('font', size=20)
        fig = plt.figure()
        # # fig.set_xlabel('Sample Value', fontsize=20)
        ax = fig.add_subplot()
        
        if trackIds is None:
            trackIds = df[idCol].unique()

        
        for trackId in trackIds:
            trackDf = df[df[idCol] == trackId]
            plt.plot(trackDf[xCol], trackDf[yCol])
            # ax.set_xlabel('Sample Value', fontsize=20)

            # plot direction
            lastRow = trackDf.tail(1)
            endPoint = (lastRow[xCol] , lastRow[yCol])
            print(endPoint[0])
            firstRow = trackDf.head(1)
            startPoint = (firstRow[xCol] , firstRow[yCol])
            # print(startPoint[0], startPoint[1])
            # plt.plot(endPoint[0], endPoint[1], marker='x')
            # diff = endPoint[0] - startPoint[0]
            # print(diff)
            
            
        ax.set_xlabel('Lateral Shift (m)', fontsize=28)
        ax.set_ylabel('Road Width (m)', fontsize=27)
        ax.set_aspect('equal', adjustable='box')
        #for scene 10 midvis
        plt.ylim(0,5)
        plt.xlim(-4,3) 
        #for scene 30 midvis
        # plt.ylim(0,5)
        # plt.xlim(-1,6)
        #for scene 10 endvis
        # plt.ylim(0,7)
        # plt.xlim(-5,4)
        # for scene 30 endvis
        # plt.ylim(0,7)
        # plt.xlim(-1,8)
        plt.savefig("midVis")
        plt.tight_layout()
        plt.show()
