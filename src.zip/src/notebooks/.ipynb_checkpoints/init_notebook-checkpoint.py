import os, sys
currentFolder = os.path.abspath('')
try:
    sys.path.remove(str(currentFolder))
except ValueError: # Already removed
    pass

projectFolder = 'C:\\Users\\Zenbook325E\\TTI-dataset-tools\\src'
# projectFolder = 'D:/AV/DataSetExploration/TTI-dataset-tools/src'
sys.path.append(str(projectFolder))
os.chdir(projectFolder)
print( f"current working dir{os.getcwd()}")
